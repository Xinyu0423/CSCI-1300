//
//  SpellChecker.cpp
//  CSCI-1300
//
//  Created by 蒋新宇 on 2017/10/30.
//  Copyright © 2017年 XInyu JIang. All rights reserved.
//

#include "SpellChecker.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;
SpellChecker::SpellChecker(){
    
}
SpellChecker::SpellChecker(string str){
    language=str;
}
SpellChecker::~SpellChecker(){
    
}
SpellChecker::SpellChecker(string str1,string str2,string str3){
    language=str1;
    firstFileName=str2;
    secondFileName=str3;
    readValidWords(str2);
    readCorrectedWords(str3);
}
bool SpellChecker::readValidWords(string str){
    firstFileName=str;
    int arrIndex=0;
    ifstream inputFile;
    inputFile.open(str);
    if(inputFile.fail()){
        return false;
    }
    while(!inputFile.eof()){
        string temp;
        getline(inputFile,temp);
        correctWords[arrIndex]=temp;
        arrIndex++;
    }
    /*for(int i=0;i<20;i++){
        cout<<"correct word number "<<i<<" "<<correctWords[i]<<endl;
    }*/
    inputFile.close();
    return true;
}
bool SpellChecker::readCorrectedWords(string filename){
    bool flag=true;
    secondFileName=filename;
    ifstream inputFile;
    inputFile.open(secondFileName.c_str());
    if(inputFile.fail()){
        //cout<<"open fail"<<endl;
        flag=false;
        return flag;
    }
    
    while(!inputFile.eof()){
        string temp;
        getline(inputFile,temp);
        //temp= temp;
        stringstream s;
        s<< temp;
        string temp2;
        getline(s,temp2,'\t');
        if(temp2!=""){
            //cout<<"temp2="<<temp<<endl;
            incorrectWords[index][0]=temp2;
            getline(s,temp2);
            //cout<<"temp2Second="<<temp<<endl;
            //cout<<"temp2="<<temp2<<endl;
            incorrectWords[index][1]=temp2;
            index++;
        }

    }
    /*for(int a=0;a<3;a++){
        for(int b=0;b<2;b++){
            cout<<incorrectWords[a][b]<<" ";
        }
        cout << endl;
    }*/
    inputFile.close();
    return flag;
}
bool SpellChecker::setStartMarker(char start){
    startChar=start;
    return true;
}
bool SpellChecker::setEndMarker(char end){
    endChar=end;
    return true;
}
char SpellChecker::getStartMarker(){
    return startChar;
}
char SpellChecker::getEndMarker(){
    return endChar;
}
string SpellChecker:: lowerNoPunctuation(string str, string punch) {
    string tempPunch=".,:!?";
    punch=tempPunch;
    int i=0;
    while(i<str.length()){
        if(str[i]>='A'&&str[i]<='Z'){
            str[i]=tolower(str[i]);
        }
        i++;
    }
    stringstream s;
    s<< str;
    string temp;
    string wholeSen="";
    while(getline(s, temp, ' ')){
        //cout<<"112 "<<temp<<endl;
        for(int j=0;j<temp.length();j++){
            for(int k=0;k<punch.length();k++){
                if(temp[0]==punch[k]){
                    temp.erase(0,1);
                    //cout<<temp<<endl;
                }
                    }
            for(int l=0;l<=punch.length();l++){
                if(temp[temp.length()-1]==punch[l]){
                    //cout<<"123"<<endl;
                    temp.erase(temp.length()-1,1);
                    //cout<<"end: "<<temp<<endl;
                    l=0;
                }
            }
        }
        //temp.erase(temp.length()-1,1);
        //cout<<"final "<<temp<<endl;
        wholeSen=wholeSen+temp+" ";
    }
    //cout<<"er  "<<wholeSen<<endl;
    return wholeSen;
}
string SpellChecker::repair(string sentence){
    sentence=lowerNoPunctuation(sentence, ".,:!?");
    //cout<<"origional sentence="<<sentence<<endl;
    string wholeSentence="";
    int countSpace=0;
    for(int i = 0;i < sentence.length() ;i++){
        if(sentence[i] == ' '){
            countSpace++;
        }
    }
        for(int j = 0;j < countSpace+1; j++){
            string temp;
            stringstream s;
            bool flag=false;
            s << sentence;
            getline(s, temp, ' ');
            sentence.erase(0, sentence.find(' ')+1);
            //cout<<"temp= "<<temp<<endl;
        for(int i = 0; i<10000 ;i++){
            //cout<<"temp= "<<temp<<endl;
            if(incorrectWords[i][0] == temp){
                flag=true;
                //cout<<"temp= "<<temp<<endl;
                temp=incorrectWords[i][1];
                //cout<<"whole  "<<wholeSentence<<endl;
                wholeSentence=wholeSentence+temp+" ";
                //cout<<"whole sentence  "<<wholeSentence<<endl;
                break;
                //cout<<"123"<<endl;
            }else if(correctWords[i] == temp){
                //cout<<"temp2= "<<temp<<endl;
                wholeSentence=wholeSentence+temp+" ";
                flag=true;
                break;
            }
            
        }
            if(flag==false){
                wholeSentence=wholeSentence+startChar+temp+endChar+" ";
            }
    }
    if(wholeSentence[wholeSentence.length()-1]==' '){
        
    }
    return wholeSentence;
    
}

