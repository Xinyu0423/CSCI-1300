//
//  main.cpp
//  CSCI-1300
//
//  Created by 蒋新宇 on 2017/10/31.
//  Copyright © 2017年 XInyu JIang. All rights reserved.
//

#include<iostream>
#include<fstream>
#include "SpellChecker.h"
#include "WordCounts.h"
int main(){
    /*SpellChecker test("English","VALID_WORDS_3000.txt","MISSPELLED.txt");
    cout<<test.readValidWords("VALID_WORDS_3000.txt")<<endl;
    cout<<test.readCorrectedWords("MISSPELLED.txt")<<endl;
    //test.readCorrectedWords("MISSPELLED2.txt");
    cout<<test.readCorrectedWords("abc.txt")<<endl;
    test.lowerNoPunctuation("...today..!!! is the day.!!!!"," .,:!?");
    test.setStartMarker('~');
    test.setEndMarker('-');
    //cout<<test.repair("todayy, is teh dayy!")<<endl;
    cout<<test.repair("!todayy is the day! jhgvjhgv")<<endl;
    //cout<<test.repair("abouy")<<endl;
    cout<<test.repair("tomor is another day!")<<endl;
    //todayy, is teh dayy!*/
    WordCounts test2;
    
    test2.tallyWords("The brown fox the fox");
    test2.tallyWords("the red fox");
    test2.tallyWords("the blue cat");
    test2.getTally("the");
    test2.getTally("fox");
    //test2.resetTally();
    string str[10];//={"the","fox","is","brown","the","brown","brown","brown","the","fox"};
    int intArr[10];//={3,2,1,4};
    test2.mostTimes(str, intArr, 4);
    
    
    
}
