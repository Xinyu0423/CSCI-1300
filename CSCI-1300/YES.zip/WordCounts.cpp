//
//  WordCounts.cpp
//  CSCI-1300
//
//  Created by 蒋新宇 on 2017/11/3.
//  Copyright © 2017年 XInyu JIang. All rights reserved.
//

#include "WordCounts.h"
#include <iostream>
#include <sstream>
using namespace std;
WordCounts::WordCounts(){
    wordsIndex=0;
    countIndex=0;
}
WordCounts::~WordCounts(){
}
string WordCounts::lowerNoPunctuation(string str, string punch){
    string tempPunch=".,:!?";
    punch=tempPunch;
    int i=0;
    while(i<str.length()){
        if(str[i]>='A'&&str[i]<='Z'){
            str[i]=tolower(str[i]);
        }
        i++;
    }
    stringstream s;
    s<< str;
    string temp;
    string wholeSen="";
    while(getline(s, temp, ' ')){
        //cout<<"112 "<<temp<<endl;
        for(int j=0;j<temp.length();j++){
            for(int k=0;k<punch.length();k++){
                if(temp[0]==punch[k]){
                    temp.erase(0,1);
                    //cout<<temp<<endl;
                }
            }
            for(int l=0;l<=punch.length();l++){
                if(temp[temp.length()-1]==punch[l]){
                    //cout<<"123"<<endl;
                    temp.erase(temp.length()-1,1);
                    //cout<<"end: "<<temp<<endl;
                    l=0;
                }
            }
        }
        wholeSen=wholeSen+temp+" ";
    }
    return wholeSen;
}

int WordCounts::isUnique(string str){
    for(int i=0;i<10000;i++){
        if(str==words[i]){
            
            return i;
        }
            //cout<<"how many times "<<i<<endl;
    }
    return -1;
}

void WordCounts::tallyWords(string sentence){
    sentence=lowerNoPunctuation(sentence, ".,:!?");
    stringstream s;
    s<< sentence;
    string temp;
//  cout<<"wordIndex= "<<wordsIndex<<endl;
    while(getline(s, temp , ' ')){
        //for(int i=0;i<5;i++){
        //cout<<"bool value"<<isUnique(temp)<<endl;
        //int tempInt=0;
        
        if(isUnique(temp)==-1){
            //cout<<"123"<<endl;
            //cout << temp << endl;

            words[wordsIndex]=temp;
            count[wordsIndex]=1;
            wordsIndex++;
            
        }else if(isUnique(temp)!=-1){
            count[isUnique(temp)]=count[isUnique(temp)]+1;
            //cout << count[isUnique(temp)] << endl;
        }
    }
//    for(int i=0;i<5;i++){
//        cout<<"words= "<<words[i]<<endl;
//    }
//    for(int i=0;i<5;i++){
//        cout<<"count= "<<count[i]<<endl;
//    }
    //cout<<"wordIndex="<<wordsIndex<<endl;
    
}
int WordCounts::getTally(string word){
    for(int i=0;i<sizeof(word);i++){
        if(words[i]==word){
            return count[i];
        }
    }
    //cout<<"count="<<count[i]<<endl;
    return 0;
}
void WordCounts::resetTally(){
    for(int i=0;i<wordsIndex;i++){
        count[i]=0;
    }
//    for(int i=0;i<wordsIndex;i++){
//        cout<<"after reset"<<count[i]<<endl;
//    }
}
int WordCounts::mostTimes(string topWords[],int topCcount[], int n){
    int tempInt;
    string tempString;
    
//    cout << "------------------------------" << endl;
//    for(int i=0;i<wordsIndex;i++){
//        cout<<words[i] << " " << count[i]<<endl;
//    }
//    cout << "------------------------------" << endl;
    
    bool sorted = false;
    
    while(!sorted) {
        sorted = true;
        for(int idx = 0; idx < wordsIndex-1; idx++) {
            if(count[idx] < count[idx+1]) {
                int tempInt = count[idx];
                count[idx]=count[idx+1];
                count[idx+1]=tempInt;
                
                //swap the integer
                string tempString=words[idx];
                words[idx]=words[idx+1];
                words[idx+1]=tempString;
                //swap the word

                
            }
        }
    }
    /*
    
    for(int i=0; i<wordsIndex; i++){
        for(int j=1; j<wordsIndex; j++){
            
            if(count[j-1] < count[j]){
                tempInt = count[j-1];
                count[j-1]=count[j];
                count[j]=tempInt;
                
                //swap the integer
                tempString=words[j-1];
                words[j-1]=words[j];
                words[j]=tempString;
                //swap the word
            }
        }
    }
     */
    
    /*
    for(int i=0;i<wordsIndex;i++){
        cout<<words[i] << " " << count[i]<<endl;
    }
    for(int i=0;i<wordsIndex;i++){
        cout<<count[i]<<endl;
    }
     */
    
//    cout << "-------   final result --------" << endl;
//    for(int i=0;i<wordsIndex;i++){
//        cout<<words[i] << " " << count[i]<<endl;
//    }
//    cout << "------------------------------" << endl;
    
    
//    
    for (int i = 0; i < n && i < wordsIndex; i++) {
        topWords[i] = words[i];
        topCcount[i] = count[i];
    }
    
    if(wordsIndex < n) {
        return wordsIndex;
    }
    return n;
    
    return wordsIndex;

}
